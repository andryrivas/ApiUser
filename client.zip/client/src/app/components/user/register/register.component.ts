import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { UserInterface } from 'src/app/models/user-interface';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { NgForm } from '@angular/forms/src/directives/ng_form';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  constructor(private authService: AuthService, private router: Router, private location: Location) { }
  private user: UserInterface = {
    username: '',
    password: ''
  };
  public isError = false;
  public isSuccess = false;
  public msgError = '';
  public msgSuccess = '';
  ngOnInit() { }

  onRegister(form: NgForm): void {
    if (form.valid) {
      this.authService
        .registerUser(this.user.username, this.user.password)
        .subscribe(user => {
          this.msgSuccess = '¡Ha sido registrado con exito! En unos segundos será redirigido.';
          this.onIsSuccess();
        },
        res => {
          console.log(res);
          if (res.status === 409) {
            this.msgError = 'El correo ya se encuentra registrado';
          } else {
            this.msgError = 'Ha habido un error. Intente de nuevo';
          }
          this.onIsError();
        });
    } else {
      this.onIsError();
    }

  }

  onIsError(): void {
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 4000);
  }

  onIsSuccess(): void {
    this.isSuccess = true;
    setTimeout(() => {
      this.router.navigate(['/user/login']); // Redirige a la página de login
    }, 4000);
  }
}
