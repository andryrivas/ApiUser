import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { map } from 'rxjs/operators';
import { AuthService } from './auth.service';
import { UserInterface } from '../models/user-interface';

@Injectable({
  providedIn: 'root'
})
export class DataApiService {

  constructor(private http: HttpClient, private authService: AuthService) { }

  user: Observable<any>;
  users: Observable<any>;
  public selectedUser: UserInterface = {
    _id: '',
    username: '',
  };
    headers: HttpHeaders = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: this.authService.getToken()
    });
  
  getAllUsers(){
    const url_api = 'http://51.38.51.187:3333/api/v1/users'
    return this.http.get(url_api);
  }

  deleteUser(_id: string) {
    // TODO: obtener token
    // TODO: not null
    const token = this.authService.getToken();
    console.log(token);
    const url_api = `http://51.38.51.187:3333/api/v1/users/${_id}`;
    return this.http
      .delete<UserInterface>(url_api, { headers: this.headers })
      .pipe(map(data => data));
  }
}
