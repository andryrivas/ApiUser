import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { UserInterface } from 'src/app/models/user-interface';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { FormBuilder, Validators } from '@angular/forms';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  constructor(private authService: AuthService, private router: Router, private formBuilder: FormBuilder) { }

  loginForm = this.formBuilder.group({
    username: [null, [Validators.required, Validators.minLength(8)]],
    password: [null, [Validators.required, Validators.pattern(/^[a-zA-Z]\w{3,14}$/)]]
  })

  public msgError;
  public msgSuccess;

  ngOnInit() {
    if (this.authService.getToken()) {
      this.router.navigate(['/users']); 
    }
  }

  onRegister(): void {
    const user = this.loginForm.value; 
    this.authService
      .registerUser(user.username, user.password)
      .subscribe(user => {
        this.msgSuccess = '¡Ha sido registrado con éxito! En unos segundos será redirigido.';
        setTimeout(() => {
          this.router.navigate(['/login']); // Redirige a la página de login
        }, 4000);
      },
      res => {
        if (res.status === 409) {
          this.msgError = 'El correo ya se encuentra registrado';
        } else {
          this.msgError = 'Ha habido un error. Intente de nuevo';
        }
        setTimeout(() => {
          this.msgError = undefined;
        }, 4000);
      });
  }
}