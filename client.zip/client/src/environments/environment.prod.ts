export const environment = {
  production: true,
  apiURL: 'http://51.38.51.187:3333/api/v1/'

};
