import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { map } from 'rxjs/operators';
import { isNullOrUndefined } from 'util';

import { UserInterface } from '../models/user-interface';
import { environment } from '../../environments/environment';
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  readonly API_URL = environment.apiURL;

  constructor(private http: HttpClient) {}

  registerUser(username: string, password: string) {
    return this.http
      .post<UserInterface>(
        `${this.API_URL}auth/register`,
        {
          username,
          password
        }
      )
      .pipe(map(data => data));
  }

  loginuser(username: string, password: string): Observable<any> {
    return this.http
      .post<UserInterface>(
        `${this.API_URL}auth/login`,
        { username, password }
      );
  }

  setUser(user: UserInterface): void {
    const userStr = JSON.stringify(user);
    localStorage.setItem('currentUser', userStr);
  }

  setToken(token): void {
    localStorage.setItem('accessToken', token);
  }

  getToken() {
    return localStorage.getItem('accessToken');
  }

  setTokenType(type): void {
    localStorage.setItem('tokenType', type);
  }

  getTokenType() {
    return localStorage.getItem('tokenType');
  }

  getCurrentUser(): UserInterface {
    const userStr = localStorage.getItem('currentUser');
    if (!isNullOrUndefined(userStr)) {
      const user: UserInterface = JSON.parse(userStr);
      return user;
    } else {
      return null;
    }
  }

  logoutUser() {
    localStorage.removeItem('accessToken');
    localStorage.removeItem('currentUser');
    return this.http.post<UserInterface>(`${this.API_URL}auth/logout`,null);
  }
}
