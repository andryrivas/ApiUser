import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { map } from 'rxjs/operators';
import { AuthService } from './auth.service';
import { UserInterface } from '../models/user-interface';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class DataApiService {
  readonly API_URL = environment.apiURL;

  constructor(private http: HttpClient, private authService: AuthService) { }

  getAllUsers() {
    return this.http.get(`${this.API_URL}users`);
  }

  deleteUser(id: string) {
    return this.http
      .delete<UserInterface>(`${this.API_URL}users/${id}`)
      .pipe(map(data => data));
  }
}
