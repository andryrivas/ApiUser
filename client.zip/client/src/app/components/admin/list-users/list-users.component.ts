import { Component, OnInit } from '@angular/core';
import { UserInterface } from './../../../models/user-interface';
import { DataApiService } from '../../../services/data-api.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-list-users',
  templateUrl: './list-users.component.html',
  styleUrls: ['./list-users.component.css']
})
export class ListUsersComponent implements OnInit {
  constructor(private dataApiService: DataApiService) { }
  private users: UserInterface;
  pageActual: number = 1;
  public myCounter: number = 0;
  ngOnInit() {
    this.getListUsers();
  }

  getListUsers(): void {
    this.dataApiService
      .getAllUsers()
      .subscribe((users: UserInterface) => (this.users = users));
  }

  onDeleteUsers(id: string): void {
    if (confirm('Esta seguro que desea eliminar el Registro?')) {
      this.dataApiService.deleteUser(id).subscribe();
    }
  }
}