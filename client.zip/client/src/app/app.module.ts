import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { ListUsersComponent } from './components/list-users/list-users.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { Page404Component } from './components/page404/page404.component';
import { HeroComponent } from './components/hero/hero.component';
import {NgxPaginationModule} from 'ngx-pagination';

//Sevicios
import { DataApiService } from 'src/app/services/data-api.service';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { TokenInterceptor } from './interceptors/token.interceptor';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    ListUsersComponent,
    LoginComponent,
    RegisterComponent,
    Page404Component,
    HeroComponent
  ],
  imports: [BrowserModule, AppRoutingModule, HttpClientModule, FormsModule, ReactiveFormsModule, NgxPaginationModule],
  providers: [
    DataApiService,
    { provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true,
      },
    ],
  bootstrap: [AppComponent]
})
export class AppModule { }
