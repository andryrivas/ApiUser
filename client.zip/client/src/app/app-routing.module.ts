import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListUsersComponent } from 'src/app/components/list-users/list-users.component';
import { LoginComponent } from 'src/app/components/login/login.component';
import { RegisterComponent } from 'src/app/components/register/register.component';
import { Page404Component } from 'src/app/components/page404/page404.component';

import { AuthGuard } from './auth.guard';

const routes: Routes = [
  { path:'', redirectTo: 'login', pathMatch: 'full' },
  { path: 'users', component: ListUsersComponent, canActivate: [AuthGuard]}, // TODO: only users auth
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  //{ path: 'user/profile', component: ProfileComponent, canActivate: [AuthGuard] }, // TODO: only users auth
  { path: '**', component: Page404Component }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
